﻿using DigitalBusiness.JsonDataWrappers.Converters;
using System.Diagnostics;
using System.Text.Json.Serialization;

namespace DigitalBusiness.JsonDataWrappers
{
    [DebuggerDisplay("{DebugDisplay,nq}")]
    [JsonConverter(typeof(TypedJsonDataJsonConverter<>))]
    /// <summary>
    /// A typed wrapper around <see cref="JsonData"/> that uses <typeparamref name="TJsonDataKey"/> as a phantom type key.
    /// <para>
    /// <typeparamref name="TJsonDataKey"/> carries no runtime data — it exists solely to allow extension methods to be
    /// scoped to a specific JSON structure. Code working with this data calls extension methods defined
    /// for the specific <typeparamref name="TJsonDataKey"/>, keeping domain logic separate from the wrapper itself.
    /// </para>
    /// <para>
    /// Use <see cref="From"/> or the constructor to create instances. Implicit cast to <see cref="JsonData"/>
    /// allows passing to any API that accepts untyped JSON data.
    /// </para>
    /// </summary>
    /// <typeparam name="TJsonDataKey">A key type implementing <see cref="IJsonDataKey"/>. May inherit from another key
    /// to inherit its extension methods.</typeparam>
    public readonly struct JsonData<TJsonDataKey> : IJsonDataWrapper where TJsonDataKey : IJsonDataKey
    {
        /// <summary>Creates a typed wrapper from an existing <see cref="JsonData"/> instance.</summary>
        public static JsonData<TJsonDataKey> From(JsonData json) => new JsonData<TJsonDataKey>(json);

        /// <summary>Wraps the given <see cref="JsonData"/>.</summary>
        public JsonData(JsonData json) { Json = json; }

        /// <summary>The underlying untyped JSON data.</summary>
        public JsonData Json { get; init; }

        /// <summary>Implicitly unwraps to <see cref="JsonData"/> for use with untyped APIs.</summary>
        public static implicit operator JsonData(JsonData<TJsonDataKey> json) => json.Json;

        private string DebugDisplay =>
        $"[{typeof(TJsonDataKey).Name}] " +
        $"[{(Json.IsNode ? "Node" : Json.IsElement ? "Element" : "Empty")}]" +
        $"[{(Json.ReadOnly ? "RO" : "RW")}] " +
        Json.ValueKind.ToString();

    }


}
