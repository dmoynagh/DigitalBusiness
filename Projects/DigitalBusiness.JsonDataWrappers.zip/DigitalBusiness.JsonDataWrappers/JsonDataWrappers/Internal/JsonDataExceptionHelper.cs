﻿using DigitalBusiness.JsonDataWrappers;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalBusiness.JsonDataWrappers.Internal
{
    /// <summary>
    /// Centralised factory for exceptions thrown by <see cref="JsonData"/> operations.
    /// Keeps error message logic out of hot paths and ensures consistent messaging.
    /// </summary>
    public static class JsonDataExceptionHelper
    {
        /// <summary>Thrown when a mutating operation is attempted on a readonly instance.</summary>
        public static Exception ReadOnlyException()
           => new InvalidOperationException("Cannot modify read-only JsonData.");

        /// <summary>Thrown when an operation is attempted on a null instance.</summary>
        public static Exception NullException() => new InvalidOperationException("JsonData is null.");

        /// <summary>Constructs an appropriate exception for a failed typed value extraction, accounting for null vs type mismatch.</summary>
        public static Exception GetTypedValueException<T>(JsonData jsonData)
        {
            if(jsonData.IsNull)  return NullException();
            return new InvalidOperationException($"Cannot get value of type {typeof(T).FullName} from JsonData with ValueKind {jsonData.ValueKind}.");
        }

        /// <summary>Constructs an exception for a failed typed property extraction.</summary>
        public static Exception GetTypedPropertyException<T>(string propertyName, JsonData objectJsonData)
        {
            if (objectJsonData.IsNull) return NullException();
            if(!objectJsonData.ContainsProperty(propertyName)) return JsonDataPropertyNotExist(propertyName);
            return new InvalidOperationException($"Cannot get value of type {typeof(T).FullName} from property '{propertyName}' with ValueKind {objectJsonData[propertyName]?.ValueKind.ToString() ?? "null"}.");
        }

        /// <summary>Constructs an exception for a failed typed index extraction.</summary>
        public static Exception GetTypedIndexException<T>(int index, JsonData arrayJsonData)
        {
            if (arrayJsonData.IsNull) return NullException();

            if (index < 0 || index >= arrayJsonData.Count) return JsonDataArrayIndexOutOfRangeException(index);

            var kindStr = arrayJsonData.TryGet(index, out var item) ? item.ValueKind.ToString() : "Unknown";
            return new InvalidOperationException($"Cannot get value of type {typeof(T).FullName} from index '{index}' with ValueKind {kindStr}.");
        }

        public static Exception JsonDataArrayIndexOutOfRangeException(int index) => new IndexOutOfRangeException($"Index '{index}' is out of range.");

        public static Exception JsonDataObjectExpectedException()=> new InvalidOperationException("JsonData is not an object.");
        public static Exception JsonDataArrayExpectedException() => new InvalidOperationException("JsonData is not an object.");


        public static Exception PropertyExistsAndNotArrayException(string propertyName)=> new InvalidOperationException($"Property '{propertyName}' exists but is not an array.");
        public static Exception PropertyExistsAndNotObjectException(string propertyName)=> new InvalidOperationException($"Property '{propertyName}' exists but is not an object.");

        public static Exception IndexExistsAndNotArrayException(int index) => new InvalidOperationException($"Index '{index}' exists but is not an array.");
        public static Exception IndexExistsAndNotObjectException(int index) => new InvalidOperationException($"Index '{index}' exists but is not an object.");


        public static Exception JsonDataPropertyNotExist(string propertyName)
        {
            return new InvalidOperationException($"Property '{propertyName}' does not exist.");
        }






        //public static Exception ArrayRequiredException(bool isNull) => 
        //    isNull ? new InvalidOperationException("Expected a JSON array but the JNode is null or value IsNull.")
        //    : new InvalidOperationException("Expected a JSON array but the JNode is not an array.");

        //public static Exception ObjectRequiredException(bool isNull) =>
        //    isNull ? new InvalidOperationException("Expected a JSON object but the JNode is null or value IsNull.")
        //    : new InvalidOperationException("Expected a JSON object but the JNode is not an object.");


        //public static Exception GetNodeValueException<T>(JsonData node) => new InvalidOperationException($"Cannot get value of type ${typeof(T).FullName} from Node type ${node.Source?.GetType().FullName ?? "null"}");


        public static Exception GetNodeValueException(Type type, JsonData node) => new InvalidOperationException($"Cannot get value of type ${type.FullName} from Node type ${node.Source?.GetType().FullName ?? "null"}");

        public static Exception GetRequiredValueException(bool allowNullNodes)
            => new InvalidOperationException($"Required node is null{(!allowNullNodes ? " or is a Null JNode." : "")}.");

    }
}
